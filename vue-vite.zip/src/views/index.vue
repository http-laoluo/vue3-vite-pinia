<template>
  <div>首页</div>
</template>

<script setup lang="ts">
  import { reactive, ref, onMounted } from 'vue'
  const data = reactive({})
  onMounted(() => {
  })
</script>
<style scoped>
</style>