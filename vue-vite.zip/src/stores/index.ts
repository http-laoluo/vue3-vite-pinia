import {useTextStore} from "./modules/text";
import {useUserStore} from "./modules/user"
export {
  useTextStore,
  useUserStore
}
