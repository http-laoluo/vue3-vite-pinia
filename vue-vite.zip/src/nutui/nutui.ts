import { 
    Button,
    Icon,
    Tabs,
    TabPane
} from "@nutui/nutui";

export default(app:any)=>{
    app.use(Button)
    app.use(Icon)
    app.use(Tabs)
    app.use(TabPane)
}
