interface ImportMetaEnv {
    VITE_MODE_NAME: string,
    VITE_RES_URL: string,
    VITE_APP_TITLE: string
  }