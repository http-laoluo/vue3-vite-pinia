
// 用户的类型声明文件
interface IUser {
    name: string;
    age: number;
}